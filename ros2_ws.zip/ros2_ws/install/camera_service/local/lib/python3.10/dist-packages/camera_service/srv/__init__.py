from camera_service.srv._cam_and_color import CamAndColor  # noqa: F401
