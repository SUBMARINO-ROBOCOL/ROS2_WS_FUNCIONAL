// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from camera_service:srv/CamAndColor.idl
// generated code does not contain a copyright notice

#ifndef CAMERA_SERVICE__SRV__DETAIL__CAM_AND_COLOR__BUILDER_HPP_
#define CAMERA_SERVICE__SRV__DETAIL__CAM_AND_COLOR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "camera_service/srv/detail/cam_and_color__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace camera_service
{

namespace srv
{

namespace builder
{

class Init_CamAndColor_Request_b
{
public:
  explicit Init_CamAndColor_Request_b(::camera_service::srv::CamAndColor_Request & msg)
  : msg_(msg)
  {}
  ::camera_service::srv::CamAndColor_Request b(::camera_service::srv::CamAndColor_Request::_b_type arg)
  {
    msg_.b = std::move(arg);
    return std::move(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Request msg_;
};

class Init_CamAndColor_Request_g
{
public:
  explicit Init_CamAndColor_Request_g(::camera_service::srv::CamAndColor_Request & msg)
  : msg_(msg)
  {}
  Init_CamAndColor_Request_b g(::camera_service::srv::CamAndColor_Request::_g_type arg)
  {
    msg_.g = std::move(arg);
    return Init_CamAndColor_Request_b(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Request msg_;
};

class Init_CamAndColor_Request_r
{
public:
  explicit Init_CamAndColor_Request_r(::camera_service::srv::CamAndColor_Request & msg)
  : msg_(msg)
  {}
  Init_CamAndColor_Request_g r(::camera_service::srv::CamAndColor_Request::_r_type arg)
  {
    msg_.r = std::move(arg);
    return Init_CamAndColor_Request_g(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Request msg_;
};

class Init_CamAndColor_Request_cam
{
public:
  Init_CamAndColor_Request_cam()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CamAndColor_Request_r cam(::camera_service::srv::CamAndColor_Request::_cam_type arg)
  {
    msg_.cam = std::move(arg);
    return Init_CamAndColor_Request_r(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::camera_service::srv::CamAndColor_Request>()
{
  return camera_service::srv::builder::Init_CamAndColor_Request_cam();
}

}  // namespace camera_service


namespace camera_service
{

namespace srv
{

namespace builder
{

class Init_CamAndColor_Response_height
{
public:
  explicit Init_CamAndColor_Response_height(::camera_service::srv::CamAndColor_Response & msg)
  : msg_(msg)
  {}
  ::camera_service::srv::CamAndColor_Response height(::camera_service::srv::CamAndColor_Response::_height_type arg)
  {
    msg_.height = std::move(arg);
    return std::move(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Response msg_;
};

class Init_CamAndColor_Response_width
{
public:
  explicit Init_CamAndColor_Response_width(::camera_service::srv::CamAndColor_Response & msg)
  : msg_(msg)
  {}
  Init_CamAndColor_Response_height width(::camera_service::srv::CamAndColor_Response::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_CamAndColor_Response_height(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Response msg_;
};

class Init_CamAndColor_Response_posy2
{
public:
  explicit Init_CamAndColor_Response_posy2(::camera_service::srv::CamAndColor_Response & msg)
  : msg_(msg)
  {}
  Init_CamAndColor_Response_width posy2(::camera_service::srv::CamAndColor_Response::_posy2_type arg)
  {
    msg_.posy2 = std::move(arg);
    return Init_CamAndColor_Response_width(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Response msg_;
};

class Init_CamAndColor_Response_posx2
{
public:
  explicit Init_CamAndColor_Response_posx2(::camera_service::srv::CamAndColor_Response & msg)
  : msg_(msg)
  {}
  Init_CamAndColor_Response_posy2 posx2(::camera_service::srv::CamAndColor_Response::_posx2_type arg)
  {
    msg_.posx2 = std::move(arg);
    return Init_CamAndColor_Response_posy2(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Response msg_;
};

class Init_CamAndColor_Response_posy1
{
public:
  explicit Init_CamAndColor_Response_posy1(::camera_service::srv::CamAndColor_Response & msg)
  : msg_(msg)
  {}
  Init_CamAndColor_Response_posx2 posy1(::camera_service::srv::CamAndColor_Response::_posy1_type arg)
  {
    msg_.posy1 = std::move(arg);
    return Init_CamAndColor_Response_posx2(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Response msg_;
};

class Init_CamAndColor_Response_posx1
{
public:
  Init_CamAndColor_Response_posx1()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CamAndColor_Response_posy1 posx1(::camera_service::srv::CamAndColor_Response::_posx1_type arg)
  {
    msg_.posx1 = std::move(arg);
    return Init_CamAndColor_Response_posy1(msg_);
  }

private:
  ::camera_service::srv::CamAndColor_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::camera_service::srv::CamAndColor_Response>()
{
  return camera_service::srv::builder::Init_CamAndColor_Response_posx1();
}

}  // namespace camera_service

#endif  // CAMERA_SERVICE__SRV__DETAIL__CAM_AND_COLOR__BUILDER_HPP_
