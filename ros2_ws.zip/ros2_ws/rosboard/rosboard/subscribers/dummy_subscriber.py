#!/usr/bin/env python3

class DummySubscriber(object):
    def __init__(self):
        pass

    def __del__(self):
        pass

    def unregister(self):
        pass

