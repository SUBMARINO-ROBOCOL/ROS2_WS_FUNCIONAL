class RosBridgeTransport {
    // not implemented yet
}