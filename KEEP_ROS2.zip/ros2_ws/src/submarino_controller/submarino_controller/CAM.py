import cv2
import cam_boton

camera = cv2.VideoCapture(0)
while True:
    check, frame = camera.read()
    cam_boton.red_box(frame)