from tutorial_interfaces.srv import CamAndColor
import rclpy
from rclpy.node import Node

import cv2
from sensor_msgs.msg import Image
import numpy as np
from cv_bridge import CvBridge

class MinimalService(Node):
	def __init__(self):
		super().__init__('minimal_service')
		self.srv = self.create_service(CamAndColor, 'cam_and_color', self.cam_and_color_callback)
	
	def listener_callback(self, msg):
		self.cvpicture = CvBridge.imgmsg_to_cv2(msg)
	
	
	def cam_and_color_callback(self, request, response):
		self.subscriber = self.create_subscription(Image, 'camera_'+str(request.cam), self.listener_callback, 10)
		
		
		
		cap = self.cvpicture
		response.width = int(cap.get(3))
		response.height = int(cap.get(4))
		
		color = [request.g,request.b,request.r]
		
		def get_limits(color):
			c = np.uint8([[color]])
			hsvC = cv2.cvtColor(c, cv2.COLOR_BGR2HSV)
			lowerLimit = hsvC[0][0][0] + 160, -50, -50
			upperLimit = hsvC[0][0][0] + 180, 200, 200
			
			lowerLimit = np.array(lowerLimit, dtype=np.uint8)
			upperLimit = np.array(upperLimit, dtype=np.uint8)
			
			return lowerLimit, upperLimit
		
		ret, frame = cap.read()

		hsvImage = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
		lowerLimit, upperLimit = get_limits(color)

		mask = cv2.inRange(hsvImage, lowerLimit, upperLimit)
		mask_ = Image.fromarray(mask)
		bbox = mask_.getbbox()

		if bbox is not None:
			response.posx1, response.posy1, response.posx2, response.posy2 = bbox
			#cam = cv2.VideoCapture(request.cam) 
			#result, image = cam.read()
			#if result:
			#	cv2.imshow("Sub Frame", image)
		else:
			response.posx1 = 0
			response.posy1 = 0
			response.posx2 = 0 
			response.posy2 = 0

		self.get_logger().info('Incoming request\na: %d b: %d c: %d, cam: %d' % (request.r, request.g, request.b, request.cam))
		
		return response
	
	
	
def main(args=None):
    rclpy.init(args=args)
    
    minimal_service = MinimalService()
    
    rclpy.spin(minimal_service)

    rclpy.shutdown()

if __name__ == '__main__':
    main()
