class RosbagTransport {
    // not yet implemented
  }
  