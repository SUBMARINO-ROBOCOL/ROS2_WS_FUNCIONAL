class DeviceSensorTransport {
    // not implemented yet
}