// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef CAMERA_SERVICE__SRV__CAM_AND_COLOR_HPP_
#define CAMERA_SERVICE__SRV__CAM_AND_COLOR_HPP_

#include "camera_service/srv/detail/cam_and_color__struct.hpp"
#include "camera_service/srv/detail/cam_and_color__builder.hpp"
#include "camera_service/srv/detail/cam_and_color__traits.hpp"

#endif  // CAMERA_SERVICE__SRV__CAM_AND_COLOR_HPP_
