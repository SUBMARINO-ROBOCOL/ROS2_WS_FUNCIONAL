// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from camera_service:srv/CamAndColor.idl
// generated code does not contain a copyright notice

#ifndef CAMERA_SERVICE__SRV__DETAIL__CAM_AND_COLOR__STRUCT_H_
#define CAMERA_SERVICE__SRV__DETAIL__CAM_AND_COLOR__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/CamAndColor in the package camera_service.
typedef struct camera_service__srv__CamAndColor_Request
{
  int64_t cam;
  int64_t r;
  int64_t g;
  int64_t b;
} camera_service__srv__CamAndColor_Request;

// Struct for a sequence of camera_service__srv__CamAndColor_Request.
typedef struct camera_service__srv__CamAndColor_Request__Sequence
{
  camera_service__srv__CamAndColor_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} camera_service__srv__CamAndColor_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/CamAndColor in the package camera_service.
typedef struct camera_service__srv__CamAndColor_Response
{
  int64_t posx1;
  int64_t posy1;
  int64_t posx2;
  int64_t posy2;
  int64_t width;
  int64_t height;
} camera_service__srv__CamAndColor_Response;

// Struct for a sequence of camera_service__srv__CamAndColor_Response.
typedef struct camera_service__srv__CamAndColor_Response__Sequence
{
  camera_service__srv__CamAndColor_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} camera_service__srv__CamAndColor_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CAMERA_SERVICE__SRV__DETAIL__CAM_AND_COLOR__STRUCT_H_
