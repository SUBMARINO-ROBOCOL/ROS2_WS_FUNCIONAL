// generated from rosidl_generator_c/resource/idl.h.em
// with input from camera_service:srv/CamAndColor.idl
// generated code does not contain a copyright notice

#ifndef CAMERA_SERVICE__SRV__CAM_AND_COLOR_H_
#define CAMERA_SERVICE__SRV__CAM_AND_COLOR_H_

#include "camera_service/srv/detail/cam_and_color__struct.h"
#include "camera_service/srv/detail/cam_and_color__functions.h"
#include "camera_service/srv/detail/cam_and_color__type_support.h"

#endif  // CAMERA_SERVICE__SRV__CAM_AND_COLOR_H_
