// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TUTORIAL_INTERFACES__SRV__CAM_AND_COLOR_HPP_
#define TUTORIAL_INTERFACES__SRV__CAM_AND_COLOR_HPP_

#include "tutorial_interfaces/srv/detail/cam_and_color__struct.hpp"
#include "tutorial_interfaces/srv/detail/cam_and_color__builder.hpp"
#include "tutorial_interfaces/srv/detail/cam_and_color__traits.hpp"

#endif  // TUTORIAL_INTERFACES__SRV__CAM_AND_COLOR_HPP_
