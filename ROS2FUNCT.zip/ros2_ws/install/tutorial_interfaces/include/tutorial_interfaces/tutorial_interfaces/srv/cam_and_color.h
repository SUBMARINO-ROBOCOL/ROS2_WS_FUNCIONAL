// generated from rosidl_generator_c/resource/idl.h.em
// with input from tutorial_interfaces:srv/CamAndColor.idl
// generated code does not contain a copyright notice

#ifndef TUTORIAL_INTERFACES__SRV__CAM_AND_COLOR_H_
#define TUTORIAL_INTERFACES__SRV__CAM_AND_COLOR_H_

#include "tutorial_interfaces/srv/detail/cam_and_color__struct.h"
#include "tutorial_interfaces/srv/detail/cam_and_color__functions.h"
#include "tutorial_interfaces/srv/detail/cam_and_color__type_support.h"

#endif  // TUTORIAL_INTERFACES__SRV__CAM_AND_COLOR_H_
